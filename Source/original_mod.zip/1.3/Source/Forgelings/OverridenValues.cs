﻿using RimWorld;

namespace Forgelings
{
    public class OverridenValues
    {
        public float? originalNutrients;
        public IngestibleProperties originalIngestibleProps;
    }
}
